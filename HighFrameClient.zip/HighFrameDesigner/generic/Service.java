package br.teste;

public interface Service {
  void print (String msg);
}
